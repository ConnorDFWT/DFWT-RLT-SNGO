# DFWT Real-time Snow Goose ARU
Real-time Snow Goose monitoring from Fraser River Delta farmland 



By Connor Hawey, DFWT

Last updated: 03/2026

# Equipment List
  1. Arduino Nano 33 BLE Sense Rev2
  2. Adafruit PCF8523 RTC
  3. Nano Connector Carrier
  4. 32 GB Micro SD card
  5. Blues Notecard Cell+WiFi (Cat-1 bis | North America)
  6. Blues Notecarrier X
  7. Qwiic to qwiic cable (Nano carrier to Nano Connector Carrier)
  8. Grove to qwiic cable (Nano carrier to RTC)
  9. LTE antenna 
  10. Voltaic systems battery V50 (13,400mAh)
  11. Soshine 15W solar panel (5V USB regulated)
  12. Breathable vent
  13. PG9 Cable gland
  14. Silica Gel packet 5g


![PXL_20251015_191257714](https://github.com/user-attachments/assets/6b27069c-e1f7-40de-93b3-d77bb252b8ab)
(Snow Goose Arduino ARU, Version 1)
